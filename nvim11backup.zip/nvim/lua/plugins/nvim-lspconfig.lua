return {
	"neovim/nvim-lspconfig",
}
